import React from 'react'
import moment from 'moment'

const VedioLength = ({time}) => {
    const vedioLengthINSeconds= moment().startOf(time).format("H:mm:ss")
return (
<div className="absolute bottom-2 right-2 bg-black px-2 text-white text-xs rounded-md">
{vedioLengthINSeconds}

</div>

)
}

export default VedioLength