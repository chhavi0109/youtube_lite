import React from "react";
import { abbreviateNumber } from "js-abbreviation-number";
import { Link } from "react-router-dom";
import { BsFillCheckCircleFill } from "react-icons/bs";
import VedioLength from "../shared/vedioLength";
const SuggestionVedio = ({video}) => {
  return (
    <Link to={`/video/${video?.videoId}`}>
      <div className="flex  mb-3">
        <div className="relative h-24 lg:h-20 xl:h-24 min-w-[168px] lg:w-32 lg:min-w-[128px] xl:w-40 xl:min-w-[168px rounded-xl bg-slate-800] overflow-hidden">
          <img
            className="h-full w-full object-cover"
            src={video?.thumbnails?.[0]?.url}
            alt="/"
          />
          {video?.lengthSeconds && <VedioLength time={video?.lengthSeconds} />}
        </div>
        <div className="flex flex-col ml-3 overflow-hidden">
            <span className=" text-sm lg:text-sm xl:text-sm font-bold line-clamp-2 text-white">
              {video?.title}
            </span>
            <span className="text-[12px] lg:text-[12px] font-semibold mt-2 text-white/[0.7] flex items-center">
              {video?.author?.title}
              {video?.author?.badges[0]?.type === "VERIFIED_CHANNEL" && (
                <BsFillCheckCircleFill
                  className="text-white/[0.5]
            text-[12px] ml-2"
                />
              )}
            </span>
            <div className="flex font-semibold text-[12px] text-white/[0.7] truncate overflow-hidden">
              <span>{`${abbreviateNumber(video?.stats?.views, 2)} views`}</span>
              <span className="flex text-white/[0.7] font-bold text-[24px] relative leading-none top-[-10px] mx-1">
                .
              </span>
              <span clasName="truncate">{video?.publishedTimeText}</span>
            </div>
          </div>
      </div>
    </Link>
  );
};

export default SuggestionVedio;
